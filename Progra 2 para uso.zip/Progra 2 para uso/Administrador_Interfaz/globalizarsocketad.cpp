#include "globalizarsocketad.h"

globalizarSocketAd::globalizarSocketAd()
{

}
