#ifndef MAINADMIN_H
#define MAINADMIN_H


class mainAdmin
{
public:
    mainAdmin();
};

#endif // MAINADMIN_H
