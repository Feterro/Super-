#ifndef GLOBALIZARSOCKETAD_H
#define GLOBALIZARSOCKETAD_H
#include "admin.h"

extern Admin socketAdmin;

#endif // GLOBALIZARSOCKETAD_H
