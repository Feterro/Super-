#ifndef GLOBALIZARCOLA_H
#define GLOBALIZARCOLA_H
#include "nodos.h"

extern colaCliente colCli;

#endif // GLOBALIZARCOLA_H
