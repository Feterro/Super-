#ifndef GLOBALSERVER_H
#define GLOBALSERVER_H
#include "server.h"

extern Servidor servGlo;

#endif // GLOBALSERVER_H
