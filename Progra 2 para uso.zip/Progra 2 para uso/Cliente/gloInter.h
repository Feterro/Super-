#ifndef GLOINTER_H
#define GLOINTER_H
#include "inter.h"

extern Inter varInt;

#endif // GLOINTER_H
