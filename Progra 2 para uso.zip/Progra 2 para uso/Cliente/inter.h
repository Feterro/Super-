#ifndef INTER_H
#define INTER_H

#include <QObject>

class Inter:QObject
{
public:
    Inter();
    bool registro;
};

#endif // INTER_H
