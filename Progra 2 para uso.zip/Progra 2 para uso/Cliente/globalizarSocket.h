#ifndef GLOBALIZARSOCKET_H
#define GLOBALIZARSOCKET_H
#include "cliente.h"

extern Cliente socketCli;

#endif // GLOBALIZARSOCKET_H
