#include "inter.h"

Inter::Inter()
{
    this->registro=true;
}
